# pyuml2svg
A library for generating SVG from user-configured UML entity and relationship classes
